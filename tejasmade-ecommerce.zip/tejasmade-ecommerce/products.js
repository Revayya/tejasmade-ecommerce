// TEJASMADE - Sample Product Catalog Data
// All product prices, photos, and descriptions are fully editable.
// Replace image URLs with your actual product photography or high-res mockups.

const CATEGORIES = [
  {
    id: "t-shirts",
    name: "Customized T-shirts",
    tagline: "Round Neck, Polo, Dry-Fit & Oversized",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80",
    description: "Premium 100% bio-wash cotton and dry-fit sublimation t-shirts with durable digital DTF, screen, and sublimation printing.",
    itemCount: "12+ Styles"
  },
  {
    id: "mugs",
    name: "Customized Mugs",
    tagline: "Glossy Ceramic, Magic & Dual-Tone Mugs",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80",
    description: "Microwave-safe AAA quality sublimation mugs with high-definition photo print, magic heat-sensitive color reveal, and corporate branding.",
    itemCount: "8+ Variants"
  },
  {
    id: "bottles-sippers",
    name: "Bottles and Sippers",
    tagline: "Stainless Steel, LED Temp & Gym Bottles",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80",
    description: "Food-grade 304 stainless steel vacuum insulated flasks, temperature display bottles, and lightweight sports sippers laser-engraved with your name or logo.",
    itemCount: "10+ Models"
  },
  {
    id: "corporate-gifts",
    name: "Corporate Gifts",
    tagline: "Executive Kits, Dairies & Tech Accessories",
    image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&auto=format&fit=crop&q=80",
    description: "Thoughtful welcome kits, executive leatherette diaries, engraved cardholders, and customized corporate gift sets for employees and clients.",
    itemCount: "15+ Combos"
  },
  {
    id: "school-uniforms",
    name: "School Uniforms",
    tagline: "Custom Uniforms, Sports Tees & Badges",
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&auto=format&fit=crop&q=80",
    description: "Color-fast, breathable school uniforms, sports house tees, customized school neckties, crest-embroidered blazers, and identification badges.",
    itemCount: "6+ Categories"
  },
  {
    id: "keychains",
    name: "Custom Keychains",
    tagline: "Laser Engraved Metal, Leather & Acrylic",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
    description: "Heavy-duty metal keyrings with deep fiber laser engraving, double-sided acrylic photo keychains, and luxury leatherette loops.",
    itemCount: "14+ Designs"
  },
  {
    id: "metal-pens",
    name: "Metal Pens",
    tagline: "Executive Laser Engraved Rollerball & Ballpoint",
    image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=800&auto=format&fit=crop&q=80",
    description: "Sophisticated matte black, chrome, and wooden barrel pens with permanent name and brand laser engraving in a velvet presentation box.",
    itemCount: "9+ Styles"
  },
  {
    id: "mouse-pads",
    name: "Mouse Pads & Desk Mats",
    tagline: "Speed Cloth, Leatherette & Gaming Mats",
    image: "https://images.unsplash.com/photo-1616440347437-b1c73416efc2?w=800&auto=format&fit=crop&q=80",
    description: "Anti-slip rubber base desktop blotters and gaming mousepads printed edge-to-edge with vibrant sublimation color fastness.",
    itemCount: "7+ Sizes"
  },
  {
    id: "photo-frames",
    name: "Photo Frames",
    tagline: "Sublimation Rock Slate, LED & Wood Frames",
    image: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80",
    description: "Natural stone rock slate frames with high-gloss photo print, acrylic LED night lamp frames, and customized collage tabletop displays.",
    itemCount: "11+ Variants"
  },
  {
    id: "personalized-gifts",
    name: "Personalized Gifts",
    tagline: "Acrylic LED Lamps, Name Plaques & Wallets",
    image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&auto=format&fit=crop&q=80",
    description: "Unique personalized keepsakes including customized 3D illusion LED lamps, engraved wooden plaques, and custom name leather wallets.",
    itemCount: "18+ Ideas"
  },
  {
    id: "gift-combos",
    name: "Customized Gift Combos",
    tagline: "Birthday, Festive & Corporate Gift Hampers",
    image: "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=800&auto=format&fit=crop&q=80",
    description: "Curated gift boxes combining customized mugs, diaries, metal pens, keychains, and photo frames in luxury magnetic gift packaging.",
    itemCount: "10+ Curated Kits"
  }
];

const PRODUCTS = [
  // Customized T-shirts
  {
    id: "tshirt-round-neck",
    name: "Custom Bio-Wash Cotton Round Neck T-Shirt",
    category: "t-shirts",
    categoryName: "Customized T-shirts",
    price: 399,
    mrp: 699,
    badge: "Bestseller",
    rating: 4.9,
    reviewCount: 38,
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Crafted from 180 GSM 100% combed bio-washed cotton. Customize with your company logo, team slogan, event branding, or personal artwork using high-resolution DTF or Screen printing.",
    features: [
      "100% Combed Bio-Wash Cotton (180 GSM)",
      "High-Definition Long-Lasting DTF Print",
      "Fade-Resistant & Machine Washable",
      "Pre-shrunk fabric to retain shape"
    ],
    variants: {
      type: "Size",
      options: ["S (38)", "M (40)", "L (42)", "XL (44)", "XXL (46)"]
    },
    colors: [
      { name: "Pure White", hex: "#FFFFFF" },
      { name: "Pitch Black", hex: "#1F2937" },
      { name: "Navy Blue", hex: "#1E3A8A" },
      { name: "Maroon", hex: "#7F1D1D" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter custom text (e.g., Company Name, Event, Nickname)",
      positions: ["Front Chest (Center)", "Left Pocket / Crest", "Back Full Width", "Left & Right Sleeve"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 399 },
      { min: 6, max: 20, price: 329 },
      { min: 21, max: 50, price: 279 },
      { min: 51, max: 200, price: 229 }
    ]
  },
  {
    id: "tshirt-polo-collar",
    name: "Corporate Embroidered / Printed Polo Collar T-Shirt",
    category: "t-shirts",
    categoryName: "Customized T-shirts",
    price: 499,
    mrp: 899,
    badge: "Corporate Favorite",
    rating: 4.8,
    reviewCount: 29,
    image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Premium 220 GSM Matty honeycomb knit polo with ribbed collar and cuffs. Ideal for corporate uniforms, executive outings, college clubs, and trade shows.",
    features: [
      "220 GSM Heavy-Duty Honeycomb Matty Fabric",
      "Option for Precision Embroidery or Digital Print",
      "Color-fast dyes suitable for daily office wear",
      "Comfort fit with reinforced collar stitches"
    ],
    variants: {
      type: "Size",
      options: ["S (38)", "M (40)", "L (42)", "XL (44)", "XXL (46)"]
    },
    colors: [
      { name: "Classic Navy", hex: "#1E293B" },
      { name: "Charcoal Grey", hex: "#475569" },
      { name: "Royal Blue", hex: "#2563EB" },
      { name: "Crisp White", hex: "#FFFFFF" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter brand or employee name",
      positions: ["Left Chest Embroidery", "Right Chest Logo", "Back Collar Print"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 499 },
      { min: 6, max: 20, price: 429 },
      { min: 21, max: 50, price: 369 },
      { min: 51, max: 200, price: 319 }
    ]
  },

  // Customized Mugs
  {
    id: "mug-glossy-ceramic",
    name: "Custom Photo & Logo Ceramic Mug (325 ml)",
    category: "mugs",
    categoryName: "Customized Mugs",
    price: 199,
    mrp: 399,
    badge: "Top Seller",
    rating: 4.9,
    reviewCount: 52,
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Export-grade AAA white ceramic mug with ultra-vibrant sublimation photo printing. Scratch-resistant, microwave and dishwasher safe, packaged in protective thermocol casing.",
    features: [
      "325 ml (11 oz) Premium AAA Grade Ceramic",
      "Sublimation printing with photographic quality",
      "Microwave and Dishwasher safe",
      "Safe bubble-wrap thermocol packaging"
    ],
    variants: {
      type: "Mug Type",
      options: ["Glossy White (325ml)", "Inner Dual-Tone Red", "Inner Dual-Tone Blue", "Inner Dual-Tone Black"]
    },
    colors: [
      { name: "Pure White", hex: "#FFFFFF" },
      { name: "Red Accent", hex: "#EF4444" },
      { name: "Blue Accent", hex: "#3B82F6" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter recipient's name or quote",
      positions: ["Full Wrap-Around (20cm x 9cm)", "Front Facing Only", "Double-Sided Logo"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 199 },
      { min: 6, max: 20, price: 159 },
      { min: 21, max: 50, price: 129 },
      { min: 51, max: 200, price: 99 }
    ]
  },
  {
    id: "mug-magic-heat-sensitive",
    name: "Magic Heat-Sensitive Color Changing Photo Mug",
    category: "mugs",
    categoryName: "Customized Mugs",
    price: 299,
    mrp: 549,
    badge: "Unique Gift",
    rating: 4.8,
    reviewCount: 44,
    image: "https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Appears solid matte black at room temperature. Pouring hot coffee or tea magically reveals your hidden custom photo, artwork, or personal message in seconds!",
    features: [
      "Matte Black thermo-chromic outer coating",
      "Reveals high-resolution photo when hot liquid is poured",
      "325 ml standard capacity",
      "A magical surprise for birthdays and anniversaries"
    ],
    variants: {
      type: "Finish",
      options: ["Matte Black Magic", "Glossy Black Magic"]
    },
    colors: [
      { name: "Magic Black", hex: "#111827" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter secret message or upload surprise photo",
      positions: ["Full Wrap-Around", "Center Front"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 299 },
      { min: 6, max: 20, price: 249 },
      { min: 21, max: 50, price: 199 },
      { min: 51, max: 200, price: 169 }
    ]
  },

  // Bottles and Sippers
  {
    id: "bottle-led-temperature",
    name: "Smart LED Temperature Display Stainless Steel Flask (500 ml)",
    category: "bottles-sippers",
    categoryName: "Bottles and Sippers",
    price: 449,
    mrp: 899,
    badge: "Trending Tech",
    rating: 4.9,
    reviewCount: 41,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Double-walled vacuum insulated flask with an interactive LED touch screen on the lid displaying water temperature in real-time. Personalized with precision fiber laser name engraving.",
    features: [
      "Food-grade 304 Stainless Steel interior",
      "Touch LED temperature sensor (500 days battery life)",
      "12-hour hot & 24-hour cold insulation",
      "Permanent silver-toned laser etching"
    ],
    variants: {
      type: "Capacity",
      options: ["500 ml"]
    },
    colors: [
      { name: "Matte Black", hex: "#1F2937" },
      { name: "Stainless Steel", hex: "#94A3B8" },
      { name: "Midnight Blue", hex: "#1E3A8A" },
      { name: "Emerald Green", hex: "#065F46" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter Name (e.g. Rahul Sharma or Logo)",
      positions: ["Vertical Side Engraving", "Horizontal Center"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 449 },
      { min: 6, max: 20, price: 389 },
      { min: 21, max: 50, price: 329 },
      { min: 51, max: 200, price: 279 }
    ]
  },
  {
    id: "bottle-sports-sipper",
    name: "Custom Aluminum Sports Sipper Bottle (750 ml)",
    category: "bottles-sippers",
    categoryName: "Bottles and Sippers",
    price: 299,
    mrp: 599,
    badge: "Gym Essential",
    rating: 4.7,
    reviewCount: 33,
    image: "https://images.unsplash.com/photo-1559825481-12a05cc00344?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1559825481-12a05cc00344?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Lightweight, shatter-proof aluminum sports bottle with carabiner clip lid. Perfect for school students, gym workouts, marathons, and cycling with vibrant sublimation prints.",
    features: [
      "750 ml lightweight aluminum alloy body",
      "Spill-proof pull top with safety cap & carabiner hook",
      "BPA Free and food safe coating",
      "Full wrap-around customized sublimation print"
    ],
    variants: {
      type: "Capacity",
      options: ["600 ml", "750 ml"]
    },
    colors: [
      { name: "Glossy White", hex: "#FFFFFF" },
      { name: "Silver Metallic", hex: "#CBD5E1" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter name or fitness slogan",
      positions: ["Full Wrap Print", "Front Logo Only"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 299 },
      { min: 6, max: 20, price: 249 },
      { min: 21, max: 50, price: 199 },
      { min: 51, max: 200, price: 169 }
    ]
  },

  // Corporate Gifts
  {
    id: "corporate-welcome-kit",
    name: "Executive 4-in-1 Corporate Welcome Kit",
    category: "corporate-gifts",
    categoryName: "Corporate Gifts",
    price: 899,
    mrp: 1499,
    badge: "Corporate Choice",
    rating: 5.0,
    reviewCount: 48,
    image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&auto=format&fit=crop&q=80"
    ],
    description: "The gold standard for new employee onboarding and corporate VIP gifting. Includes: Premium Leatherette Diary with magnetic loop, Heavy Metal Pen, 500ml Insulated Bottle, and Metal Keychain, all personalized with individual name & company logo.",
    features: [
      "Hardbound A5 Notebook with 192 Ruled 80 GSM Pages",
      "Engraved Heavy Brass Rollerball Pen",
      "Temperature or Vacuum Flask with Company Logo",
      "Stitched Leatherette Keychain with Engraved Plate",
      "Packed in a rigid magnetic luxury gift box"
    ],
    variants: {
      type: "Box Color",
      options: ["Matte Black Box", "Royal Blue Box", "Executive Brown Box"]
    },
    colors: [
      { name: "Black Edition", hex: "#111827" },
      { name: "Navy Blue Edition", hex: "#1E3A8A" },
      { name: "Tan Brown Edition", hex: "#78350F" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter Company Name / Employee Name",
      positions: ["All Items Customized with Logo & Name"]
    },
    bulkTiers: [
      { min: 1, max: 10, price: 899 },
      { min: 11, max: 50, price: 749 },
      { min: 51, max: 200, price: 649 },
      { min: 201, max: 1000, price: 549 }
    ]
  },

  // School Uniforms
  {
    id: "school-polo-uniform",
    name: "Custom School / College House Polo T-Shirt",
    category: "school-uniforms",
    categoryName: "School Uniforms",
    price: 320,
    mrp: 550,
    badge: "Bulk Order",
    rating: 4.8,
    reviewCount: 22,
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Durable school uniform polo shirts engineered for daily wear and rough sports activities. Breathable cotton-poly blend with school crest embroidery or high-density screen print.",
    features: [
      "65/35 Cotton-Poly Breathable Uniform Fabric",
      "Anti-pilling, color-fast guarantee for 100+ washes",
      "Embroidered School Crest on Chest",
      "House Color trims on collar and sleeves"
    ],
    variants: {
      type: "House / Size",
      options: ["Red (Tagore)", "Blue (Nehru)", "Green (Gandhi)", "Yellow (Patel)"]
    },
    colors: [
      { name: "Red House", hex: "#DC2626" },
      { name: "Blue House", hex: "#2563EB" },
      { name: "Green House", hex: "#16A34A" },
      { name: "Yellow House", hex: "#EAB308" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "School Name & Student House / Roll",
      positions: ["Chest Crest", "Back School Name Print"]
    },
    bulkTiers: [
      { min: 10, max: 50, price: 320 },
      { min: 51, max: 200, price: 260 },
      { min: 201, max: 1000, price: 210 }
    ]
  },

  // Keychains
  {
    id: "keychain-laser-metal",
    name: "Personalized Metal & Leather Loop Keychain",
    category: "keychains",
    categoryName: "Custom Keychains",
    price: 149,
    mrp: 299,
    badge: "Pocket Favorite",
    rating: 4.9,
    reviewCount: 65,
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Premium zinc alloy metal key tag combined with durable PU leather strap. Laser-engraved with vehicle number, initials, company branding, or personal contact number.",
    features: [
      "Solid Zinc Alloy with Gunmetal / Silver Finish",
      "Fiber Laser Engraved - Won't scratch or rub off",
      "Heavy duty snap hook and key ring",
      "Comes in a presentation envelope"
    ],
    variants: {
      type: "Metal Finish",
      options: ["Gunmetal Black", "Brushed Silver", "Rose Gold"]
    },
    colors: [
      { name: "Matte Black", hex: "#1F2937" },
      { name: "Silver Metal", hex: "#94A3B8" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter Vehicle No., Name or Text (Max 20 chars)",
      positions: ["Front Engraving", "Both Sides (+₹30)"]
    },
    bulkTiers: [
      { min: 1, max: 10, price: 149 },
      { min: 11, max: 50, price: 119 },
      { min: 51, max: 200, price: 89 },
      { min: 201, max: 1000, price: 59 }
    ]
  },

  // Metal Pens
  {
    id: "pen-executive-rollerball",
    name: "Personalized Laser-Engraved Matte Black Metal Pen",
    category: "metal-pens",
    categoryName: "Metal Pens",
    price: 199,
    mrp: 399,
    badge: "Classy Gift",
    rating: 4.9,
    reviewCount: 71,
    image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=800&auto=format&fit=crop&q=80"
    ],
    description: "A sleek, balanced brass-barrel rollerball pen in matte black with 24k gold or silver trims. Features a silky 0.7mm German ink refill and laser engraving of your name, designation, or corporate logo.",
    features: [
      "Solid Brass Barrel with anti-slip weight balance",
      "Precision German 0.7mm Blue/Black Ink Refill",
      "Golden/Silver exposed laser engraving",
      "Supplied in a velvet sleeve or hard gift box"
    ],
    variants: {
      type: "Trim Style",
      options: ["Gold Trims (0.7mm Blue Ink)", "Chrome Trims (0.7mm Blue Ink)"]
    },
    colors: [
      { name: "Matte Black & Gold", hex: "#111827" },
      { name: "Brushed Chrome", hex: "#94A3B8" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter Name or Designation to engrave",
      positions: ["Pen Barrel", "Cap Clip Area"]
    },
    bulkTiers: [
      { min: 1, max: 10, price: 199 },
      { min: 11, max: 50, price: 149 },
      { min: 51, max: 200, price: 110 },
      { min: 201, max: 1000, price: 79 }
    ]
  },

  // Mouse Pads and Desk Mats
  {
    id: "desk-mat-xl-leather",
    name: "Custom Printed Desk Blotter & XL Gaming Mouse Pad",
    category: "mouse-pads",
    categoryName: "Mouse Pads & Desk Mats",
    price: 399,
    mrp: 799,
    badge: "Desk Setup",
    rating: 4.8,
    reviewCount: 36,
    image: "https://images.unsplash.com/photo-1616440347437-b1c73416efc2?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1616440347437-b1c73416efc2?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Transform your workspace with a customized extended desk mat. Features stitched anti-fray edges, a natural rubber anti-skid base, and ultra-smooth micro-weave cloth with vibrant edge-to-edge printing.",
    features: [
      "Available in Standard (22x18cm) and Extended XL (80x30cm)",
      "High-density micro-weave fabric for precise mouse sensor tracking",
      "Anti-fraying stitched border",
      "Water-resistant and easy to wipe clean"
    ],
    variants: {
      type: "Dimensions",
      options: ["Standard (22 x 18 cm)", "Extended XL Desk Mat (80 x 30 cm)", "XXL Desk Mat (90 x 40 cm)"]
    },
    colors: [
      { name: "Full Custom Graphic", hex: "#22C55E" },
      { name: "Dark Minimalist", hex: "#111827" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Add motivational quote or developer slogan",
      positions: ["Full Edge-to-Edge Print", "Bottom Right Corner Logo"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 399 },
      { min: 6, max: 20, price: 349 },
      { min: 21, max: 50, price: 299 },
      { min: 51, max: 200, price: 249 }
    ]
  },

  // Photo Frames
  {
    id: "photo-frame-rock-slate",
    name: "Custom Sublimation Rock Slate Stone Photo Plaque",
    category: "photo-frames",
    categoryName: "Photo Frames",
    price: 499,
    mrp: 899,
    badge: "Handcrafted Feel",
    rating: 4.9,
    reviewCount: 57,
    image: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80"
    ],
    description: "Crafted from natural sedimentary rock with rustic chiseled edges. Your photograph is permanently infused onto the stone slate using high-gloss sublimation that will never peel, fade, or discolor over time.",
    features: [
      "100% Genuine Natural Stone with chiseled edges",
      "Includes two sturdy desktop display stands",
      "High-gloss waterproof and scratch-proof finish",
      "Available in Rectangle (20x15cm) and Square shapes"
    ],
    variants: {
      type: "Size & Shape",
      options: ["Rectangle SH-02 (20 x 15 cm)", "Square SH-25 (15 x 15 cm)", "Heart Shape SH-04"]
    },
    colors: [
      { name: "Natural Slate Stone", hex: "#334155" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Add special date or quote (e.g. Happy Anniversary)",
      positions: ["Direct High-Res Photo Print on Stone Face"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 499 },
      { min: 6, max: 20, price: 429 },
      { min: 21, max: 50, price: 379 },
      { min: 51, max: 200, price: 329 }
    ]
  },

  // Personalized Gifts
  {
    id: "personalized-acrylic-lamp",
    name: "Custom 3D Illusion LED Acrylic Name Night Lamp",
    category: "personalized-gifts",
    categoryName: "Personalized Gifts",
    price: 599,
    mrp: 1199,
    badge: "Anniversary Special",
    rating: 4.9,
    reviewCount: 68,
    image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&auto=format&fit=crop&q=80"
    ],
    description: "An enchanting bedside decorative lamp made from 4mm cast optical acrylic mounted on an authentic warm-wood LED base. Engraved with your couple portrait, names, and romantic or family dates.",
    features: [
      "4mm Shatter-resistant optical cast acrylic",
      "Natural Beech Wood base with warm LED illumination",
      "USB powered with on/off switch cable",
      "Precision laser engraved artwork"
    ],
    variants: {
      type: "Design Theme",
      options: ["Couple Name with Infinity", "Heart Photo Line Art", "Ganesha / Spiritual Blessing", "Baby Birth Details"]
    },
    colors: [
      { name: "Warm White Glow", hex: "#F59E0B" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter 2 Names & Anniversary Date (e.g., Rohit & Priya 24.10.2024)",
      positions: ["Front Acrylic Face"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 599 },
      { min: 6, max: 20, price: 499 },
      { min: 21, max: 50, price: 429 },
      { min: 51, max: 200, price: 369 }
    ]
  },

  // Customized Gift Combos
  {
    id: "combo-festive-hamper",
    name: "Festive Delight Customized Gift Box (4-Piece Set)",
    category: "gift-combos",
    categoryName: "Customized Gift Combos",
    price: 999,
    mrp: 1899,
    badge: "Diwali & Celebrations",
    rating: 5.0,
    reviewCount: 43,
    image: "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=800&auto=format&fit=crop&q=80"
    ],
    description: "The complete celebration hamper. Contains: 1 Custom Photo Mug, 1 Stainless Steel LED Flask with engraved name, 1 Laser Engraved Metal Keychain, and 1 Personalized Greeting Card in an artisan matte gift box with ribbon.",
    features: [
      "1x Custom Photo Ceramic Mug (325ml)",
      "1x LED Smart Temperature Flask (500ml)",
      "1x Heavy Metal Engraved Keychain",
      "1x Gold Foil Printed Greeting Card",
      "Packed with satin ribbon & festive box"
    ],
    variants: {
      type: "Occasion Theme",
      options: ["Festive (Diwali / New Year)", "Birthday Celebration", "Corporate Token of Appreciation"]
    },
    colors: [
      { name: "Midnight Blue & Gold", hex: "#1E3A8A" },
      { name: "Festive Crimson Red", hex: "#991B1B" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Enter Receiver's Name & Sender's Name / Message",
      positions: ["Mug, Bottle & Keychain Customized"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 999 },
      { min: 6, max: 20, price: 849 },
      { min: 21, max: 50, price: 749 },
      { min: 51, max: 200, price: 649 }
    ]
  },
  {
    id: "combo-birthday-surprise",
    name: "Personalized Birthday Surprise Combo",
    category: "gift-combos",
    categoryName: "Customized Gift Combos",
    price: 749,
    mrp: 1399,
    badge: "Birthday Special",
    rating: 4.9,
    reviewCount: 39,
    image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&auto=format&fit=crop&q=80",
    images: [
      "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&auto=format&fit=crop&q=80"
    ],
    description: "A heartwarming gift combo packed with joy: 1 Magic Color Changing Mug + 1 Photo Rock Slate Frame + 1 Custom Wooden Keychain.",
    features: [
      "1x Magic Photo Mug (reveals photo with hot coffee)",
      "1x Sublimation Rock Slate Photo Plaque (15x15cm)",
      "1x Double-sided custom Keychain",
      "Ready to gift birthday gift wrap included"
    ],
    variants: {
      type: "Recipient",
      options: ["For Friend / Bestie", "For Him", "For Her", "For Kids"]
    },
    colors: [
      { name: "Rainbow Celebration", hex: "#8B5CF6" }
    ],
    customization: {
      allowText: true,
      allowImageUpload: true,
      textPlaceholder: "Birthday Person's Name & Special Date",
      positions: ["Mug, Slate & Keychain"]
    },
    bulkTiers: [
      { min: 1, max: 5, price: 749 },
      { min: 6, max: 20, price: 649 },
      { min: 21, max: 50, price: 569 }
    ]
  }
];

// Sample authentic-style customer testimonials
const TESTIMONIALS = [
  {
    name: "Vikram Rathore",
    role: "Founder, Apex Logistics Bangalore",
    rating: 5,
    date: "14 Oct 2026",
    product: "Executive 4-in-1 Corporate Welcome Kit (120 units)",
    review: "We ordered 120 custom welcome kits with our company logo and individual employee names. The laser engraving on the metal pens and flasks was razor-sharp! Delivery reached Bangalore within 4 days. Exceptional service by TEJASMADE.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80"
  },
  {
    name: "Ananya Deshmukh",
    role: "Verified Buyer, Pune",
    rating: 5,
    date: "22 Sep 2026",
    product: "Magic Color Changing Photo Mug",
    review: "Ordered this for my husband's birthday. When he poured hot tea and his photo slowly appeared, he was totally blown away! The print clarity is fantastic and it arrived very safely packed in thick thermocol.",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80"
  },
  {
    name: "Principal R. K. Sharma",
    role: "St. Xavier's Academy",
    rating: 5,
    date: "05 Aug 2026",
    product: "Custom School House Polo Uniforms (350 pcs)",
    review: "TEJASMADE handled our entire school annual sports meet t-shirt requirements. The house color vibrant prints, comfortable breathable fabric, and prompt communication on WhatsApp made the entire process seamless.",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80"
  },
  {
    name: "Meera Nair",
    role: "Verified Buyer, Kochi",
    rating: 5,
    date: "18 Sep 2026",
    product: "Custom Sublimation Rock Slate Stone",
    review: "The natural stone texture makes the photo look like a museum art piece. Everyone visiting our living room asks where we got this made. Truly worth every rupee!",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80"
  }
];

// Sample Instagram / Customer Showcase Gallery
const GALLERY_ITEMS = [
  {
    title: "Sublimation Coffee Mug for Cafe Studio",
    tag: "@tejasmade_official",
    category: "mugs",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80"
  },
  {
    title: "Smart LED Temperature Bottles Batch",
    tag: "@tejasmade_official",
    category: "bottles-sippers",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&auto=format&fit=crop&q=80"
  },
  {
    title: "Bio-Wash Screen Printed Tech Tees",
    tag: "@tejasmade_official",
    category: "t-shirts",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80"
  },
  {
    title: "Executive Brass Laser Engraved Pens",
    tag: "@tejasmade_official",
    category: "metal-pens",
    image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=600&auto=format&fit=crop&q=80"
  },
  {
    title: "Extended XL Desk Mat Setup",
    tag: "@tejasmade_official",
    category: "mouse-pads",
    image: "https://images.unsplash.com/photo-1616440347437-b1c73416efc2?w=600&auto=format&fit=crop&q=80"
  },
  {
    title: "Festive Custom Hampers Ready for Dispatch",
    tag: "@tejasmade_official",
    category: "gift-combos",
    image: "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=600&auto=format&fit=crop&q=80"
  }
];

// Business contact constants
const BUSINESS_INFO = {
  name: "TEJASMADE",
  tagline: "CUSTOM MADE. JUST FOR YOU.",
  phone: "9606799579",
  phoneDisplay: "+91 96067 99579",
  whatsapp: "9606799579",
  whatsappUrl: "https://wa.me/919606799579",
  email: "tejasmadeofficial@gmail.com",
  instagram: "@tejasmade_official",
  instagramUrl: "https://instagram.com/tejasmade_official",
  shipping: "Pan-India Express & Standard Delivery",
  operatingHours: "Monday – Saturday: 9:30 AM – 7:30 PM IST"
};
