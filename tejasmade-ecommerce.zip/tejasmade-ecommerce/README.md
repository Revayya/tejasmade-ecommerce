# TEJASMADE - Complete E-Commerce Website

> **Tagline:** *CUSTOM MADE. JUST FOR YOU.*  
> **Business Focus:** Indian customized products, printing, and personalized gifts brand.

---

## 🌟 Overview & Highlights

This project is a complete, production-ready, mobile-friendly e-commerce storefront crafted for **TEJASMADE**, inspired by the category-driven layout and wholesale/retail shopping experience of leading Indian blanks and sublimation portals, but with original branding, clean typography, and modern interactive features.

### Key Sections & Features Included:
1. **Promotional Announcement Bar:** PAN-India free shipping notice, active WhatsApp support link, and official contact info.
2. **Hero Banner:** Features high-definition product imagery, the brand tagline *"CUSTOM MADE. JUST FOR YOU."*, and dual CTA buttons (*Shop Now* & *Customize Your Order*).
3. **Shop by Categories:** Interactive image tiles covering all 11 required categories:
   - Customized T-shirts (Round neck, Corporate Polo, Dry-fit)
   - Customized Mugs (Ceramic glossy, Magic color-changing, Dual-tone)
   - Bottles and Sippers (Smart LED temperature flasks, Sports sippers)
   - Corporate Gifts (Executive 4-in-1 welcome kits, leatherette diaries)
   - School Uniforms (Sublimation house polos, sports tees, crest embroidery)
   - Keychains (Laser-engraved metal, acrylic, stitched leather loops)
   - Metal Pens (Matte black rollerball, gold-trim laser engraved pens)
   - Mouse Pads and Desk Mats (Stitched-edge XL desk blotters)
   - Photo Frames (Natural stone rock slate frames, LED acrylic lamps)
   - Personalized Gifts (3D optical illusion night lamps, custom wallets)
   - Customized Gift Combos (Festive celebration boxes, birthday hampers)
4. **Featured Products & New Arrivals:** Filter tabs, search bar, sort dropdown, realistic editable sample prices in INR (₹), and quick action buttons.
5. **Interactive Live Product Customizer Modal:**
   - Real-time product mockup preview canvas
   - Live custom text rendering with multiple font styles and print color selection
   - Logo / photo upload simulator (previewing uploaded designs directly on the mockup)
   - Variant/size selection and placement options
   - Real-time bulk wholesale discount calculator (e.g. 1-5 pcs, 6-20 pcs, 21-50 pcs, 51-200 pcs)
   - Instant *"Order on WhatsApp"* button that formats all product details into a chat link
6. **Customized Gift Combos Section:** Curated hampers with gift box packaging details.
7. **Corporate & Bulk Orders RFP Generator:** Dedicated inquiry form for schools, colleges, companies, and organizations that auto-formats requirements into WhatsApp and Email.
8. **How It Works (4 Steps):** Choose a product &rarr; Share your design &rarr; Approve digital mockup &rarr; Doorstep delivery.
9. **Why Choose TEJASMADE, Customer Testimonials & Instagram Showcase Gallery:** Authentic style reviews and photo feed integration (@tejasmade_official).
10. **Shopping Cart Drawer & Checkout Modal:**
    - Slide-out cart drawer with quantity counters
    - Free shipping progress bar (unlocked at ₹999+)
    - Pincode delivery estimator for Indian pincodes
    - Promo coupons (`TEJAS10` for 10% off, `BULK20` for 20% off wholesale orders)
    - Indian address form with Pincode, City, and State selectors
    - Payment preferences (UPI / QR, WhatsApp Assist, Advance Partial COD)
    - Order Confirmation modal generating reference IDs (e.g., `TM-849201`) with direct WhatsApp order forwarding.

---

## 📁 File Structure

```text
tejasmade-ecommerce/
│
├── index.html        # Main storefront HTML with all 9 homepage sections & modals
├── styles.css        # Premium styles, fonts, smooth animations, and mockup canvas styles
├── products.js       # Complete editable product catalog data (all 11 categories & tiers)
├── app.js            # Reactive application logic (Cart, Customizer, Checkout, WhatsApp)
└── README.md         # Documentation, GoDaddy deployment guide, and maintenance instructions
```

---

## 🚀 How to Open and Preview Locally

You do not need any backend server, Node.js, or complex build steps! The website is built with clean modern web standards.

1. Open File Explorer and navigate to:
   ```text
   C:\Users\hp\.gemini\antigravity\scratch\tejasmade-ecommerce
   ```
2. Double-click **`index.html`** to open it immediately in **Google Chrome**, **Microsoft Edge**, **Mozilla Firefox**, or **Brave**.
3. Test all features:
   - Click any category to filter products.
   - Click **"Customize"** on any product to open the live mockup canvas, enter custom text, choose fonts, colors, and upload your logo.
   - Adjust quantities to see bulk wholesale tier price calculations.
   - Click **"Add to Cart"** or **"Order on WhatsApp"**.
   - Test the checkout form and generate a simulated order confirmation.

---

## 🛠️ How to Edit Products, Prices, and Photos

All product information is organized cleanly in **`products.js`**.

To add, edit, or replace a product:
1. Open `products.js` in your code editor or Notepad.
2. Locate the product inside the `PRODUCTS` array.
3. Update the fields:
   ```javascript
   {
     id: "tshirt-round-neck",
     name: "Your Product Name",
     category: "t-shirts",
     price: 399,       // Your actual selling price in INR
     mrp: 699,         // Crossed-out MRP
     image: "https://your-domain.com/path-to-image.jpg", // Replace with your actual photo
     description: "Product description...",
     bulkTiers: [
       { min: 1, max: 5, price: 399 },
       { min: 6, max: 20, price: 329 }
     ]
   }
   ```
4. Save the file and refresh your browser.

---

## 🌐 How to Deploy to GoDaddy or Any Web Hosting

### Method A: GoDaddy cPanel / Web Hosting (Recommended)
1. Log into your **GoDaddy Account** and navigate to **My Products** &rarr; **Web Hosting** &rarr; **Manage**.
2. Click on **cPanel Admin** and open the **File Manager**.
3. Open the **`public_html`** directory (or your website's root folder).
4. Upload the 4 files directly:
   - `index.html`
   - `styles.css`
   - `products.js`
   - `app.js`
5. Visit your domain (e.g. `www.tejasmade.com`) — your website is live immediately!

### Method B: Netlify / Vercel / GitHub Pages (Free Instant SSL Hosting)
1. Drag and drop the `tejasmade-ecommerce` folder into **Netlify Drop** (app.netlify.com/drop).
2. It will deploy in under 10 seconds with a free SSL certificate (`https://`).
3. Connect your GoDaddy custom domain via DNS records.

---

## 📞 Official TEJASMADE Business Details

- **Brand:** TEJASMADE
- **Tagline:** CUSTOM MADE. JUST FOR YOU.
- **Phone / WhatsApp:** +91 96067 99579
- **Email:** tejasmadeofficial@gmail.com
- **Instagram:** [@tejasmade_official](https://instagram.com/tejasmade_official)
