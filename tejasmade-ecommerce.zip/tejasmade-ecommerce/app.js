// TEJASMADE - E-Commerce Web Application Logic
// Inspired by sublimationblankproducts.com category-driven layout with custom branding

// App State
const state = {
  cart: JSON.parse(localStorage.getItem('tejasmade_cart')) || [],
  wishlist: JSON.parse(localStorage.getItem('tejasmade_wishlist')) || [],
  selectedCategory: 'all',
  searchQuery: '',
  sortBy: 'featured',
  activeProduct: null,
  customization: {
    text: '',
    font: 'Outfit, sans-serif',
    textColor: '#1E293B',
    variant: '',
    color: '',
    quantity: 1,
    uploadedImage: null,
    position: 'Front Chest (Center)'
  },
  discountCode: '',
  discountPercent: 0,
  pincodeDeliveryDays: null
};

// Save state to localStorage
function saveState() {
  localStorage.setItem('tejasmade_cart', JSON.stringify(state.cart));
  localStorage.setItem('tejasmade_wishlist', JSON.stringify(state.wishlist));
  updateBadges();
}

// Initialize on DOM Loaded
document.addEventListener('DOMContentLoaded', () => {
  renderCategoriesGrid();
  renderCategoryFilterPills();
  renderProductsGrid();
  renderGiftCombos();
  renderTestimonials();
  renderGallery();
  updateBadges();
  setupEventListeners();
  initLucide();
});

// Helper to initialize Lucide icons
function initLucide() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

// Update Header / Mobile Navigation Badges
function updateBadges() {
  const totalItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartBadges = document.querySelectorAll('.cart-badge');
  cartBadges.forEach(badge => {
    badge.textContent = totalItems;
    badge.style.display = totalItems > 0 ? 'flex' : 'none';
  });

  const wishlistCount = state.wishlist.length;
  const wishBadges = document.querySelectorAll('.wishlist-badge');
  wishBadges.forEach(badge => {
    badge.textContent = wishlistCount;
    badge.style.display = wishlistCount > 0 ? 'flex' : 'none';
  });
}

// 1. Render Categories Grid
function renderCategoriesGrid() {
  const container = document.getElementById('categories-grid');
  if (!container) return;

  container.innerHTML = CATEGORIES.map(cat => `
    <div class="category-card group bg-white rounded-2xl p-4 cursor-pointer text-center relative overflow-hidden" onclick="filterByCategory('${cat.id}')">
      <div class="w-full aspect-square rounded-xl overflow-hidden bg-slate-100 mb-3 relative">
        <img src="${cat.image}" alt="${cat.name}" class="cat-img w-full h-full object-cover transition-transform duration-500" loading="lazy" />
        <span class="absolute top-2 right-2 bg-slate-900/80 backdrop-blur-sm text-white text-[11px] font-medium px-2 py-0.5 rounded-full">
          ${cat.itemCount}
        </span>
      </div>
      <h3 class="font-bold text-slate-800 text-sm md:text-base group-hover:text-rose-600 transition-colors">
        ${cat.name}
      </h3>
      <p class="text-xs text-slate-500 mt-0.5 line-clamp-1">
        ${cat.tagline}
      </p>
    </div>
  `).join('');
}

// 2. Render Category Filter Pills
function renderCategoryFilterPills() {
  const container = document.getElementById('category-filter-pills');
  if (!container) return;

  const allButton = `
    <button onclick="filterByCategory('all')" class="category-pill whitespace-nowrap px-4 py-2 rounded-full text-xs md:text-sm font-semibold transition-all ${state.selectedCategory === 'all' ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
      All Products (${PRODUCTS.length})
    </button>
  `;

  const categoryButtons = CATEGORIES.map(cat => {
    const count = PRODUCTS.filter(p => p.category === cat.id).length;
    const isSelected = state.selectedCategory === cat.id;
    return `
      <button onclick="filterByCategory('${cat.id}')" class="category-pill whitespace-nowrap px-4 py-2 rounded-full text-xs md:text-sm font-semibold transition-all ${isSelected ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}">
        ${cat.name} ${count > 0 ? `(${count})` : ''}
      </button>
    `;
  }).join('');

  container.innerHTML = allButton + categoryButtons;
}

// Filter products by category
function filterByCategory(catId) {
  state.selectedCategory = catId;
  renderCategoryFilterPills();
  renderProductsGrid();
  
  // Smooth scroll to shop section
  const section = document.getElementById('shop-section');
  if (section) {
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// 3. Render Products Grid with Filter and Sorting
function renderProductsGrid() {
  const container = document.getElementById('products-grid');
  if (!container) return;

  let filtered = [...PRODUCTS];

  // Category filter
  if (state.selectedCategory !== 'all') {
    filtered = filtered.filter(p => p.category === state.selectedCategory);
  }

  // Search filter
  if (state.searchQuery.trim() !== '') {
    const q = state.searchQuery.toLowerCase();
    filtered = filtered.filter(p => 
      p.name.toLowerCase().includes(q) || 
      p.categoryName.toLowerCase().includes(q) || 
      p.description.toLowerCase().includes(q)
    );
  }

  // Sorting
  if (state.sortBy === 'price-low') {
    filtered.sort((a, b) => a.price - b.price);
  } else if (state.sortBy === 'price-high') {
    filtered.sort((a, b) => b.price - a.price);
  } else if (state.sortBy === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full py-16 text-center">
        <i data-lucide="package-search" class="w-16 h-16 text-slate-300 mx-auto mb-4"></i>
        <h3 class="text-lg font-bold text-slate-700">No products match your search</h3>
        <p class="text-sm text-slate-500 mt-1">Try another category or clear your search term.</p>
        <button onclick="clearFilters()" class="mt-4 px-5 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors">
          View All Products
        </button>
      </div>
    `;
    initLucide();
    return;
  }

  container.innerHTML = filtered.map(product => {
    const isWishlisted = state.wishlist.includes(product.id);
    const discount = Math.round(((product.mrp - product.price) / product.mrp) * 100);

    return `
      <div class="product-card group relative flex flex-col justify-between">
        <!-- Badges & Wishlist -->
        <div class="relative w-full aspect-square bg-slate-50 overflow-hidden">
          <img src="${product.image}" alt="${product.name}" class="product-img w-full h-full object-cover" loading="lazy" />
          
          <div class="absolute top-3 left-3 flex flex-col gap-1 z-10">
            ${product.badge ? `
              <span class="badge-bestseller text-[11px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider">
                ${product.badge}
              </span>
            ` : ''}
            <span class="bg-rose-500 text-white text-[11px] font-bold px-2 py-0.5 rounded-md">
              ${discount}% OFF
            </span>
          </div>

          <button onclick="toggleWishlist('${product.id}', event)" class="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm shadow flex items-center justify-center text-slate-600 hover:text-rose-500 hover:bg-white transition-all z-10" title="Wishlist">
            <i data-lucide="heart" class="w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}"></i>
          </button>

          <!-- Quick Action Overlay on Desktop -->
          <div class="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-all duration-300 flex gap-2 z-10 hidden md:flex">
            <button onclick="openCustomizer('${product.id}')" class="flex-1 bg-slate-900 text-white py-2 px-3 rounded-lg text-xs font-semibold hover:bg-rose-600 transition-colors flex items-center justify-center gap-1.5 shadow-lg">
              <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
              Customize Now
            </button>
            <button onclick="openQuickView('${product.id}')" class="w-9 h-9 bg-white text-slate-800 rounded-lg flex items-center justify-center shadow-lg hover:bg-slate-100 transition-colors" title="Quick View">
              <i data-lucide="eye" class="w-4 h-4"></i>
            </button>
          </div>
        </div>

        <!-- Product Info -->
        <div class="p-4 flex-1 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>${product.categoryName}</span>
              <div class="flex items-center gap-1 text-amber-500 font-bold">
                <i data-lucide="star" class="w-3.5 h-3.5 fill-amber-400"></i>
                <span>${product.rating}</span>
                <span class="text-slate-400 font-normal">(${product.reviewCount})</span>
              </div>
            </div>
            
            <h4 class="font-bold text-slate-900 text-sm line-clamp-2 hover:text-rose-600 cursor-pointer" onclick="openCustomizer('${product.id}')">
              ${product.name}
            </h4>
          </div>

          <div class="mt-4 pt-3 border-t border-slate-100">
            <div class="flex items-baseline gap-2 mb-3">
              <span class="text-lg font-black text-slate-900">₹${product.price}</span>
              <span class="text-xs text-slate-400 line-through">₹${product.mrp}</span>
              <span class="text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded ml-auto">
                Bulk: From ₹${product.bulkTiers[product.bulkTiers.length - 1].price}
              </span>
            </div>

            <!-- Mobile & Default CTA -->
            <div class="grid grid-cols-2 gap-2">
              <button onclick="openCustomizer('${product.id}')" class="w-full bg-slate-900 hover:bg-rose-600 text-white py-2 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1">
                <i data-lucide="palette" class="w-3.5 h-3.5"></i>
                Customize
              </button>
              <button onclick="quickAddToCart('${product.id}')" class="w-full border border-slate-200 hover:border-slate-800 text-slate-800 py-2 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1">
                <i data-lucide="shopping-bag" class="w-3.5 h-3.5"></i>
                Add Cart
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');

  initLucide();
}

function clearFilters() {
  state.selectedCategory = 'all';
  state.searchQuery = '';
  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.value = '';
  renderCategoryFilterPills();
  renderProductsGrid();
}

// 4. Render Customized Gift Combos
function renderGiftCombos() {
  const container = document.getElementById('gift-combos-grid');
  if (!container) return;

  const combos = PRODUCTS.filter(p => p.category === 'gift-combos');

  container.innerHTML = combos.map(combo => `
    <div class="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl text-white overflow-hidden shadow-xl flex flex-col md:flex-row group">
      <div class="md:w-1/2 relative aspect-video md:aspect-auto overflow-hidden">
        <img src="${combo.image}" alt="${combo.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        <span class="absolute top-4 left-4 bg-amber-400 text-slate-950 text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
          ${combo.badge || 'Curated Hamper'}
        </span>
      </div>
      <div class="p-6 md:p-8 md:w-1/2 flex flex-col justify-between">
        <div>
          <div class="flex items-center gap-2 text-amber-300 text-xs font-semibold mb-2">
            <i data-lucide="gift" class="w-4 h-4"></i>
            <span>Ready-to-Gift Packaging Included</span>
          </div>
          <h3 class="text-xl md:text-2xl font-black text-white mb-2">${combo.name}</h3>
          <p class="text-slate-300 text-xs md:text-sm mb-4 leading-relaxed">${combo.description}</p>
          
          <ul class="space-y-1.5 mb-6 text-xs text-slate-200">
            ${combo.features.slice(0, 3).map(f => `
              <li class="flex items-center gap-2">
                <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-400 shrink-0"></i>
                <span>${f}</span>
              </li>
            `).join('')}
          </ul>
        </div>

        <div class="pt-4 border-t border-slate-700/60 flex items-center justify-between">
          <div>
            <div class="text-xs text-slate-400">Combo Price</div>
            <div class="flex items-baseline gap-2">
              <span class="text-2xl font-black text-white">₹${combo.price}</span>
              <span class="text-sm text-slate-400 line-through">₹${combo.mrp}</span>
            </div>
          </div>
          <button onclick="openCustomizer('${combo.id}')" class="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs md:text-sm font-bold transition-all shadow-lg hover:shadow-rose-600/30 flex items-center gap-1.5">
            <i data-lucide="sparkles" class="w-4 h-4"></i>
            Personalize Combo
          </button>
        </div>
      </div>
    </div>
  `).join('');

  initLucide();
}

// 5. Render Testimonials
function renderTestimonials() {
  const container = document.getElementById('testimonials-grid');
  if (!container) return;

  container.innerHTML = TESTIMONIALS.map(t => `
    <div class="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
      <div>
        <div class="flex items-center gap-1 text-amber-400 mb-3">
          ${Array(t.rating).fill('<i data-lucide="star" class="w-4 h-4 fill-amber-400"></i>').join('')}
        </div>
        <p class="text-slate-600 text-sm italic leading-relaxed mb-4">"${t.review}"</p>
        <div class="text-[11px] font-semibold text-rose-600 bg-rose-50 px-2 py-1 rounded inline-block mb-4">
          Ordered: ${t.product}
        </div>
      </div>

      <div class="flex items-center gap-3 pt-3 border-t border-slate-100">
        <img src="${t.avatar}" alt="${t.name}" class="w-10 h-10 rounded-full object-cover border border-slate-200" />
        <div>
          <h5 class="text-sm font-bold text-slate-900">${t.name}</h5>
          <p class="text-xs text-slate-500">${t.role}</p>
        </div>
      </div>
    </div>
  `).join('');

  initLucide();
}

// 6. Render Customer Gallery / Instagram Feed
function renderGallery() {
  const container = document.getElementById('gallery-grid');
  if (!container) return;

  container.innerHTML = GALLERY_ITEMS.map(item => `
    <div class="relative group aspect-square rounded-2xl overflow-hidden bg-slate-100 shadow-sm cursor-pointer" onclick="openInstagramProfile()">
      <img src="${item.image}" alt="${item.title}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
      <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end text-white">
        <div class="flex items-center gap-1.5 text-xs text-rose-400 font-semibold mb-1">
          <i data-lucide="instagram" class="w-3.5 h-3.5"></i>
          <span>${item.tag}</span>
        </div>
        <p class="text-xs font-medium text-slate-200 line-clamp-2">${item.title}</p>
      </div>
    </div>
  `).join('');

  initLucide();
}

function openInstagramProfile() {
  window.open(BUSINESS_INFO.instagramUrl, '_blank');
}

// Wishlist Functionality
function toggleWishlist(productId, event) {
  if (event) event.stopPropagation();

  const index = state.wishlist.indexOf(productId);
  if (index > -1) {
    state.wishlist.splice(index, 1);
    showToast('Removed from your Wishlist');
  } else {
    state.wishlist.push(productId);
    showToast('Added to your Wishlist ❤️');
  }
  saveState();
  renderProductsGrid();
}

// Quick Add to Cart without customization
function quickAddToCart(productId) {
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return;

  const defaultVariant = product.variants ? product.variants.options[0] : 'Standard';
  const defaultColor = product.colors ? product.colors[0].name : 'Default';

  const cartItem = {
    cartItemId: Date.now().toString(),
    productId: product.id,
    name: product.name,
    categoryName: product.categoryName,
    price: product.price,
    mrp: product.mrp,
    image: product.image,
    variant: defaultVariant,
    color: defaultColor,
    customText: '',
    customFont: 'Outfit, sans-serif',
    customTextColor: '#000000',
    uploadedImage: null,
    position: 'Front Center',
    quantity: 1,
    subtotal: product.price
  };

  state.cart.push(cartItem);
  saveState();
  showToast(`Added "${product.name}" to your cart! 🛍️`);
  openCartDrawer();
}

// ==========================================
// 7. Interactive Customizer Modal Logic
// ==========================================
function openCustomizer(productId) {
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return;

  state.activeProduct = product;
  state.customization = {
    text: '',
    font: 'Outfit, sans-serif',
    textColor: '#1E293B',
    variant: product.variants ? product.variants.options[0] : 'Standard',
    color: product.colors ? product.colors[0].name : 'Default',
    quantity: 1,
    uploadedImage: null,
    position: product.customization && product.customization.positions ? product.customization.positions[0] : 'Front'
  };

  const modal = document.getElementById('customizer-modal');
  if (!modal) return;

  renderCustomizerUI();
  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  initLucide();
}

function closeCustomizer() {
  const modal = document.getElementById('customizer-modal');
  if (modal) modal.classList.add('hidden');
  document.body.style.overflow = '';
  state.activeProduct = null;
}

function renderCustomizerUI() {
  const p = state.activeProduct;
  if (!p) return;

  // Set Modal Title & Category
  document.getElementById('customizer-title').textContent = p.name;
  document.getElementById('customizer-category').textContent = p.categoryName;
  document.getElementById('customizer-description').textContent = p.description;

  // Base mockup image
  const mockupImg = document.getElementById('customizer-mockup-img');
  mockupImg.src = p.image;

  // Setup Variants
  const variantContainer = document.getElementById('customizer-variants-container');
  if (p.variants) {
    variantContainer.innerHTML = `
      <label class="block text-xs font-bold text-slate-700 mb-1.5">${p.variants.type || 'Select Option'}:</label>
      <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
        ${p.variants.options.map((opt, i) => `
          <button type="button" onclick="setCustomVariant('${opt}')" class="variant-opt-btn px-3 py-2 border rounded-lg text-xs font-semibold text-center transition-all ${opt === state.customization.variant ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-700 hover:border-slate-400'}">
            ${opt}
          </button>
        `).join('')}
      </div>
    `;
  } else {
    variantContainer.innerHTML = '';
  }

  // Setup Colors
  const colorsContainer = document.getElementById('customizer-colors-container');
  if (p.colors && p.colors.length > 0) {
    colorsContainer.innerHTML = `
      <label class="block text-xs font-bold text-slate-700 mb-1.5">Color / Finish: <span class="font-normal text-slate-500" id="selected-color-label">${state.customization.color}</span></label>
      <div class="flex items-center gap-2">
        ${p.colors.map(c => `
          <button type="button" onclick="setCustomColor('${c.name}', '${c.hex}')" class="w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 flex items-center justify-center ${c.name === state.customization.color ? 'ring-2 ring-rose-500 ring-offset-2' : 'border-slate-300'}" style="background-color: ${c.hex}" title="${c.name}">
          </button>
        `).join('')}
      </div>
    `;
  } else {
    colorsContainer.innerHTML = '';
  }

  // Setup Positions
  const posContainer = document.getElementById('customizer-positions-container');
  if (p.customization && p.customization.positions) {
    posContainer.innerHTML = `
      <label class="block text-xs font-bold text-slate-700 mb-1.5">Print Placement:</label>
      <select onchange="setCustomPosition(this.value)" class="w-full text-xs font-medium border border-slate-200 rounded-lg p-2.5 bg-white text-slate-800 focus:outline-none focus:border-slate-900">
        ${p.customization.positions.map(pos => `
          <option value="${pos}" ${pos === state.customization.position ? 'selected' : ''}>${pos}</option>
        `).join('')}
      </select>
    `;
  } else {
    posContainer.innerHTML = '';
  }

  // Bulk Tier Table
  const tierContainer = document.getElementById('customizer-bulk-tiers');
  tierContainer.innerHTML = `
    <div class="bg-slate-50 p-3 rounded-xl border border-slate-200/80 mb-4">
      <div class="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Wholesale & Bulk Price Tiers</div>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-center">
        ${p.bulkTiers.map(tier => {
          const isCurrentTier = state.customization.quantity >= tier.min && (tier.max ? state.customization.quantity <= tier.max : true);
          return `
            <div class="p-2 rounded-lg text-xs transition-all ${isCurrentTier ? 'bg-emerald-600 text-white font-bold shadow-sm' : 'bg-white border border-slate-200 text-slate-700'}">
              <div>${tier.min}${tier.max ? `-${tier.max}` : '+'} pcs</div>
              <div class="text-sm font-black mt-0.5">₹${tier.price}</div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  // Text Placeholder
  const textInput = document.getElementById('custom-text-input');
  textInput.value = state.customization.text;
  textInput.placeholder = (p.customization && p.customization.textPlaceholder) || "Enter custom text or name";

  updateCustomizerPreview();
  updateCustomizerPrice();
}

function setCustomVariant(opt) {
  state.customization.variant = opt;
  renderCustomizerUI();
}

function setCustomColor(colorName, hex) {
  state.customization.color = colorName;
  const label = document.getElementById('selected-color-label');
  if (label) label.textContent = colorName;
  renderCustomizerUI();
}

function setCustomPosition(val) {
  state.customization.position = val;
}

function onCustomTextChange(val) {
  state.customization.text = val;
  updateCustomizerPreview();
}

function setCustomFont(fontFamily) {
  state.customization.font = fontFamily;
  document.querySelectorAll('.font-choice-btn').forEach(btn => {
    btn.classList.toggle('bg-slate-900', btn.dataset.font === fontFamily);
    btn.classList.toggle('text-white', btn.dataset.font === fontFamily);
    btn.classList.toggle('border-slate-900', btn.dataset.font === fontFamily);
  });
  updateCustomizerPreview();
}

function setCustomTextColor(colorHex) {
  state.customization.textColor = colorHex;
  updateCustomizerPreview();
}

function handleCustomImageUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    state.customization.uploadedImage = e.target.result;
    state.customization.uploadedFileName = file.name;
    updateCustomizerPreview();
    showToast(`Logo "${file.name}" loaded for preview!`);
  };
  reader.readAsDataURL(file);
}

function removeCustomUploadedImage() {
  state.customization.uploadedImage = null;
  state.customization.uploadedFileName = null;
  const fileInput = document.getElementById('custom-file-input');
  if (fileInput) fileInput.value = '';
  updateCustomizerPreview();
}

function updateCustomizerPreview() {
  const textDisplay = document.getElementById('mockup-custom-text');
  const imgDisplay = document.getElementById('mockup-custom-image');
  const overlayBox = document.getElementById('custom-overlay-box');
  const uploadTag = document.getElementById('uploaded-file-tag');

  if (state.customization.text.trim()) {
    textDisplay.textContent = state.customization.text;
    textDisplay.style.fontFamily = state.customization.font;
    textDisplay.style.color = state.customization.textColor;
    textDisplay.style.display = 'block';
  } else {
    textDisplay.textContent = 'YOUR TEXT HERE';
    textDisplay.style.color = '#94A3B8';
    textDisplay.style.fontFamily = state.customization.font;
  }

  if (state.customization.uploadedImage) {
    imgDisplay.src = state.customization.uploadedImage;
    imgDisplay.classList.remove('hidden');
    if (uploadTag) {
      uploadTag.classList.remove('hidden');
      uploadTag.querySelector('span').textContent = state.customization.uploadedFileName || 'Design Uploaded';
    }
  } else {
    imgDisplay.classList.add('hidden');
    if (uploadTag) uploadTag.classList.add('hidden');
  }

  overlayBox.classList.add('active-border');
}

function adjustQuantity(delta) {
  const newQty = Math.max(1, state.customization.quantity + delta);
  state.customization.quantity = newQty;
  document.getElementById('custom-qty-display').textContent = newQty;
  renderCustomizerUI();
}

function calculateCurrentUnitPrice(product, qty) {
  if (!product.bulkTiers || product.bulkTiers.length === 0) return product.price;
  for (let i = product.bulkTiers.length - 1; i >= 0; i--) {
    const tier = product.bulkTiers[i];
    if (qty >= tier.min) {
      return tier.price;
    }
  }
  return product.price;
}

function updateCustomizerPrice() {
  const p = state.activeProduct;
  if (!p) return;

  const unitPrice = calculateCurrentUnitPrice(p, state.customization.quantity);
  const total = unitPrice * state.customization.quantity;

  document.getElementById('custom-unit-price').textContent = `₹${unitPrice}`;
  document.getElementById('custom-total-price').textContent = `₹${total}`;
}

// Add customized product to Cart
function addCustomizedToCart() {
  const p = state.activeProduct;
  if (!p) return;

  const unitPrice = calculateCurrentUnitPrice(p, state.customization.quantity);
  const total = unitPrice * state.customization.quantity;

  const cartItem = {
    cartItemId: Date.now().toString(),
    productId: p.id,
    name: p.name,
    categoryName: p.categoryName,
    price: unitPrice,
    mrp: p.mrp,
    image: p.image,
    variant: state.customization.variant,
    color: state.customization.color,
    customText: state.customization.text,
    customFont: state.customization.font,
    customTextColor: state.customization.textColor,
    uploadedImage: state.customization.uploadedImage,
    uploadedFileName: state.customization.uploadedFileName,
    position: state.customization.position,
    quantity: state.customization.quantity,
    subtotal: total
  };

  state.cart.push(cartItem);
  saveState();
  closeCustomizer();
  showToast(`Added ${state.customization.quantity}x "${p.name}" to cart! ✨`);
  openCartDrawer();
}

// Order directly on WhatsApp from Customizer
function orderDirectOnWhatsApp() {
  const p = state.activeProduct;
  if (!p) return;

  const unitPrice = calculateCurrentUnitPrice(p, state.customization.quantity);
  const total = unitPrice * state.customization.quantity;

  let msg = `*NEW ORDER / INQUIRY - TEJASMADE*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `*Product:* ${p.name}\n`;
  msg += `*Category:* ${p.categoryName}\n`;
  msg += `*Option / Size:* ${state.customization.variant}\n`;
  msg += `*Color / Finish:* ${state.customization.color}\n`;
  msg += `*Quantity:* ${state.customization.quantity} pcs\n`;
  msg += `*Unit Price:* ₹${unitPrice}\n`;
  msg += `*Estimated Total:* ₹${total}\n`;
  
  if (state.customization.text.trim()) {
    msg += `*Custom Text / Name:* ${state.customization.text}\n`;
    msg += `*Placement:* ${state.customization.position}\n`;
  }
  if (state.customization.uploadedFileName) {
    msg += `*Logo / Image:* Yes, I have a logo ready to share here on WhatsApp (${state.customization.uploadedFileName})\n`;
  }
  msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `Hi TEJASMADE Team, please verify my customization requirement and guide me with the order confirmation!`;

  const url = `https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

// Quick View Modal
function openQuickView(productId) {
  openCustomizer(productId);
}

// ==========================================
// 8. Shopping Cart Drawer Logic
// ==========================================
function openCartDrawer() {
  const drawer = document.getElementById('cart-drawer');
  if (!drawer) return;
  drawer.classList.remove('hidden');
  renderCartDrawerItems();
  initLucide();
}

function closeCartDrawer() {
  const drawer = document.getElementById('cart-drawer');
  if (drawer) drawer.classList.add('hidden');
}

function renderCartDrawerItems() {
  const container = document.getElementById('cart-items-container');
  const emptyState = document.getElementById('cart-empty-state');
  const footer = document.getElementById('cart-drawer-footer');
  if (!container) return;

  if (state.cart.length === 0) {
    container.innerHTML = '';
    emptyState.classList.remove('hidden');
    footer.classList.add('hidden');
    return;
  }

  emptyState.classList.add('hidden');
  footer.classList.remove('hidden');

  container.innerHTML = state.cart.map(item => `
    <div class="flex gap-3 py-3 border-b border-slate-100 relative group">
      <div class="w-16 h-16 rounded-xl bg-slate-100 overflow-hidden shrink-0 border border-slate-200">
        <img src="${item.image}" alt="${item.name}" class="w-full h-full object-cover" />
      </div>

      <div class="flex-1">
        <div class="flex justify-between items-start gap-1">
          <h5 class="text-xs font-bold text-slate-800 line-clamp-1">${item.name}</h5>
          <button onclick="removeCartItem('${item.cartItemId}')" class="text-slate-400 hover:text-rose-500 transition-colors p-1" title="Remove">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>

        <div class="text-[11px] text-slate-500 mt-0.5">
          <span>${item.variant}</span> | <span>${item.color}</span>
        </div>

        ${item.customText ? `
          <div class="text-[10px] text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded mt-1 inline-block font-medium">
            Text: "${item.customText}"
          </div>
        ` : ''}

        <div class="flex items-center justify-between mt-2">
          <div class="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
            <button onclick="updateCartItemQty('${item.cartItemId}', -1)" class="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-200 text-xs font-bold">-</button>
            <span class="w-7 text-center text-xs font-semibold text-slate-800">${item.quantity}</span>
            <button onclick="updateCartItemQty('${item.cartItemId}', 1)" class="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-200 text-xs font-bold">+</button>
          </div>
          <span class="text-xs font-black text-slate-900">₹${item.price * item.quantity}</span>
        </div>
      </div>
    </div>
  `).join('');

  // Calculate totals
  const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = Math.round(subtotal * (state.discountPercent / 100));
  const shipping = subtotal >= 999 || subtotal === 0 ? 0 : 70;
  const grandTotal = Math.max(0, subtotal - discountAmount + shipping);

  document.getElementById('cart-subtotal').textContent = `₹${subtotal}`;
  document.getElementById('cart-discount-row').classList.toggle('hidden', state.discountPercent === 0);
  document.getElementById('cart-discount-amount').textContent = `-₹${discountAmount}`;
  document.getElementById('cart-shipping').textContent = shipping === 0 ? 'FREE' : `₹${shipping}`;
  document.getElementById('cart-grand-total').textContent = `₹${grandTotal}`;

  // Free shipping progress bar
  const freeThreshold = 999;
  const shippingProgress = Math.min(100, Math.round((subtotal / freeThreshold) * 100));
  const freeShippingBar = document.getElementById('free-shipping-progress');
  const freeShippingText = document.getElementById('free-shipping-text');
  
  if (freeShippingBar && freeShippingText) {
    freeShippingBar.style.width = `${shippingProgress}%`;
    if (subtotal >= freeThreshold) {
      freeShippingText.innerHTML = `<span class="text-emerald-600 font-bold">🎉 Congratulations! You have unlocked FREE Pan-India Shipping!</span>`;
    } else {
      freeShippingText.innerHTML = `Add <span class="font-bold text-slate-900">₹${freeThreshold - subtotal}</span> more to get <strong>FREE Pan-India Shipping</strong>!`;
    }
  }

  initLucide();
}

function updateCartItemQty(cartItemId, delta) {
  const item = state.cart.find(i => i.cartItemId === cartItemId);
  if (!item) return;

  item.quantity += delta;
  if (item.quantity <= 0) {
    removeCartItem(cartItemId);
  } else {
    // Recalculate price tier if possible
    const product = PRODUCTS.find(p => p.id === item.productId);
    if (product) {
      item.price = calculateCurrentUnitPrice(product, item.quantity);
      item.subtotal = item.price * item.quantity;
    }
    saveState();
    renderCartDrawerItems();
  }
}

function removeCartItem(cartItemId) {
  state.cart = state.cart.filter(i => i.cartItemId !== cartItemId);
  saveState();
  renderCartDrawerItems();
  showToast('Item removed from cart');
}

// Promo Code Logic
function applyCoupon() {
  const input = document.getElementById('coupon-input');
  if (!input) return;
  const code = input.value.trim().toUpperCase();

  if (code === 'TEJAS10') {
    state.discountCode = 'TEJAS10';
    state.discountPercent = 10;
    showToast('Promo code TEJAS10 applied: 10% OFF! 🎉');
  } else if (code === 'BULK20') {
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    if (subtotal >= 2000) {
      state.discountCode = 'BULK20';
      state.discountPercent = 20;
      showToast('Wholesale coupon BULK20 applied: 20% OFF! 🚀');
    } else {
      showToast('BULK20 is valid on orders above ₹2000 only.');
    }
  } else {
    showToast('Invalid coupon code. Try "TEJAS10" for 10% off.');
  }

  renderCartDrawerItems();
}

// Pincode Check
function checkPincode() {
  const input = document.getElementById('pincode-input');
  const result = document.getElementById('pincode-result');
  if (!input || !result) return;

  const pin = input.value.trim();
  if (/^[1-9][0-9]{5}$/.test(pin)) {
    result.classList.remove('hidden');
    result.innerHTML = `
      <div class="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 p-2 rounded-lg font-medium">
        <i data-lucide="truck" class="w-4 h-4 text-emerald-600"></i>
        <span>Delivery available to pincode <strong>${pin}</strong> in 3-5 business days. Express dispatch available.</span>
      </div>
    `;
    initLucide();
  } else {
    result.classList.remove('hidden');
    result.innerHTML = `<span class="text-xs text-rose-500">Please enter a valid 6-digit Indian pincode</span>`;
  }
}

// ==========================================
// 9. Checkout & Order Placement Logic
// ==========================================
function openCheckoutModal() {
  if (state.cart.length === 0) {
    showToast('Your cart is empty. Please add items to checkout.');
    return;
  }
  closeCartDrawer();
  const modal = document.getElementById('checkout-modal');
  if (!modal) return;

  renderCheckoutSummary();
  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  initLucide();
}

function closeCheckoutModal() {
  const modal = document.getElementById('checkout-modal');
  if (modal) modal.classList.add('hidden');
  document.body.style.overflow = '';
}

function renderCheckoutSummary() {
  const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = Math.round(subtotal * (state.discountPercent / 100));
  const shipping = subtotal >= 999 ? 0 : 70;
  const grandTotal = Math.max(0, subtotal - discountAmount + shipping);

  document.getElementById('checkout-subtotal').textContent = `₹${subtotal}`;
  document.getElementById('checkout-shipping').textContent = shipping === 0 ? 'FREE' : `₹${shipping}`;
  document.getElementById('checkout-grand-total').textContent = `₹${grandTotal}`;

  const itemsList = document.getElementById('checkout-items-list');
  if (itemsList) {
    itemsList.innerHTML = state.cart.map(item => `
      <div class="flex justify-between items-center text-xs py-1.5 border-b border-slate-100">
        <div class="flex items-center gap-2">
          <span class="w-5 h-5 rounded bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-[10px]">${item.quantity}x</span>
          <span class="font-medium text-slate-800 line-clamp-1">${item.name} (${item.variant})</span>
        </div>
        <span class="font-bold text-slate-900">₹${item.price * item.quantity}</span>
      </div>
    `).join('');
  }
}

function handleOrderSubmit(event) {
  event.preventDefault();

  const name = document.getElementById('cust-name').value.trim();
  const phone = document.getElementById('cust-phone').value.trim();
  const email = document.getElementById('cust-email').value.trim();
  const address = document.getElementById('cust-address').value.trim();
  const pincode = document.getElementById('cust-pincode').value.trim();
  const city = document.getElementById('cust-city').value.trim();
  const stateVal = document.getElementById('cust-state').value.trim();
  const notes = document.getElementById('cust-notes').value.trim();
  const paymentMethod = document.querySelector('input[name="payment-method"]:checked')?.value || 'WhatsApp / UPI Direct';

  if (!name || !phone || !address || !pincode) {
    showToast('Please fill in all required address fields.');
    return;
  }

  const orderId = 'TM-' + Math.floor(100000 + Math.random() * 900000);
  const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = Math.round(subtotal * (state.discountPercent / 100));
  const shipping = subtotal >= 999 ? 0 : 70;
  const grandTotal = subtotal - discountAmount + shipping;

  const orderData = {
    orderId,
    date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
    customer: { name, phone, email, address, city, state: stateVal, pincode, notes },
    items: [...state.cart],
    subtotal,
    discountAmount,
    shipping,
    grandTotal,
    paymentMethod
  };

  // Close Checkout Modal & Open Order Confirmation Screen
  closeCheckoutModal();
  openOrderSuccessModal(orderData);

  // Clear Cart
  state.cart = [];
  state.discountPercent = 0;
  state.discountCode = '';
  saveState();
}

function openOrderSuccessModal(order) {
  const modal = document.getElementById('order-success-modal');
  if (!modal) return;

  document.getElementById('success-order-id').textContent = order.orderId;
  document.getElementById('success-customer-name').textContent = order.customer.name;
  document.getElementById('success-total-amount').textContent = `₹${order.grandTotal}`;
  document.getElementById('success-phone').textContent = order.customer.phone;

  // Build formatted WhatsApp message for quick order confirmation
  let waMsg = `*ORDER PLACED - TEJASMADE (Ref: ${order.orderId})*\n`;
  waMsg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  waMsg += `*Customer:* ${order.customer.name}\n`;
  waMsg += `*Phone:* ${order.customer.phone}\n`;
  waMsg += `*Delivery Address:* ${order.customer.address}, ${order.customer.city}, ${order.customer.state} - ${order.customer.pincode}\n`;
  waMsg += `*Payment Method:* ${order.paymentMethod}\n`;
  waMsg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  waMsg += `*ITEMS ORDERED:*\n`;
  
  order.items.forEach((item, idx) => {
    waMsg += `${idx + 1}. ${item.name} (${item.variant}) x ${item.quantity} = ₹${item.price * item.quantity}\n`;
    if (item.customText) {
      waMsg += `   - Custom Text: "${item.customText}"\n`;
    }
  });

  waMsg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  waMsg += `*Total Amount:* ₹${order.grandTotal}\n\n`;
  waMsg += `Hi TEJASMADE team, I have placed this order on your website. Please confirm my order and share printing mockup / UPI payment details. Thank you!`;

  const waBtn = document.getElementById('success-whatsapp-btn');
  if (waBtn) {
    waBtn.href = `https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(waMsg)}`;
  }

  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  initLucide();
}

function closeOrderSuccessModal() {
  const modal = document.getElementById('order-success-modal');
  if (modal) modal.classList.add('hidden');
  document.body.style.overflow = '';
}

// ==========================================
// 10. Corporate Bulk Order RFP Generator
// ==========================================
function handleCorporateEnquiry(event) {
  event.preventDefault();

  const company = document.getElementById('corp-company').value.trim();
  const contactName = document.getElementById('corp-name').value.trim();
  const phone = document.getElementById('corp-phone').value.trim();
  const email = document.getElementById('corp-email').value.trim();
  const category = document.getElementById('corp-category').value;
  const quantity = document.getElementById('corp-quantity').value;
  const budget = document.getElementById('corp-budget').value.trim();
  const notes = document.getElementById('corp-notes').value.trim();

  let msg = `*CORPORATE & BULK ORDER RFP - TEJASMADE*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `*Organization / School / Club:* ${company}\n`;
  msg += `*Contact Person:* ${contactName}\n`;
  msg += `*Phone / WhatsApp:* ${phone}\n`;
  msg += `*Email:* ${email}\n`;
  msg += `*Product Requirement:* ${category}\n`;
  msg += `*Approx. Quantity:* ${quantity} units\n`;
  if (budget) msg += `*Target Budget / Pc:* ₹${budget}\n`;
  if (notes) msg += `*Specific Details:* ${notes}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `Please provide your formal wholesale quotation, sample mockup, and estimated dispatch timeline.`;

  const url = `https://wa.me/91${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
  showToast('Opening WhatsApp with your corporate RFP specifications! 💼');
}

// ==========================================
// 11. Search Overlay & UI Event Listeners
// ==========================================
function setupEventListeners() {
  // Search input live trigger
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value;
      renderProductsGrid();
    });
  }

  // Sort dropdown trigger
  const sortSelect = document.getElementById('sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      state.sortBy = e.target.value;
      renderProductsGrid();
    });
  }

  // Keyboard shortcut to close modals on ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeCustomizer();
      closeCartDrawer();
      closeCheckoutModal();
      closeOrderSuccessModal();
    }
  });
}

// Toast Notification Engine
function showToast(message) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast-msg';
  toast.innerHTML = `
    <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400 shrink-0"></i>
    <span class="flex-1">${message}</span>
  `;

  container.appendChild(toast);
  initLucide();

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}
